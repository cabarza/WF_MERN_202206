console.log('El resultado 1 == "1" es: ', 1 == "1" );
console.log('El resultado 1 === "1" es: ', 1 === "1" );
console.log('El resultado 1 != "1" es: ', 1 != "1" );